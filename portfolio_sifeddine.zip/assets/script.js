
// Example script for dark mode toggle in future
console.log("Portfolio loaded.");
